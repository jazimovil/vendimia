<?php
include_once 't.php';
$t = new Things();
include_once 'db.php';
$db = new MyDB();

$ventas = $db->getVentas();
$porcEnganche = $db->getConfig('porcEnganche');
$tasaFinanciamiento = $db->getConfig('tasaFinanciamiento');
$plazoM = $db->getConfig('plazoM');
?>
<!DOCTYPE html>
<html>
<head>
	<title>La Vendimia - Ventas</title>
	<?=$t->css?>
</head>
<body>
	<?=$t->topContent()?>

	<div id="content">

		<div id="uno">
			<button id="btn-new"><i class="fa fa-plus-circle"></i> Nueva Venta</button>
			<h3>Ventas activas</h3>
			<table class="tbl" cellspacing="0">
				<thead>
					<tr>
						<th>Folio Venta</th>
						<th>Clave cliente</th>
						<th>Nombre</th>
						<th>Total</th>
						<th>Fecha</th>
					</tr>
				</thead>
				<tbody>
					<?php
					if ($ventas) foreach ($ventas as $v) {
						$fecha = date("d/m/Y", strtotime($v['fecha']));
						echo "<tr><td>{$v['folio']}</td><td>{$v['clave']}</td><td>{$v['nombre']}</td><td>{$v['total']}</td><td>$fecha</td></tr>";
					}
					?>
				</tbody>
			</table>
		</div>

		<div id="dos" style="margin-top: 50px; display: none;">
			<div class="caja">
				<div class="cajatop">
					Registro de Ventas
				</div>
				<div class="cajabody">
					<form id="ventaTotal">
						<div class="label folio">Folio Venta: <?=str_pad($db->getNextId('ventas'), 4, '0', STR_PAD_LEFT)?><input type="hidden" name="folio" value="<?=$db->getNextId('ventas')?>"></div>
						<table>
							<tr>
								<td>Cliente:</td>
								<td>
									<input type="text" id="cliente" onkeyup="if (this.value.length > 2) searchC(this.value)" placeholder="Buscar cliente..." autocomplete="off">
									<div class="sugerencias c"></div>
									<input type="hidden" id="clvC" name="clave">
								</td>
								<td>RFC: <span id="rfc"></span></td>
							</tr>
							<tr>
								<td>Articulo:</td>
								<td>
									<input type="text" id="articulo" onkeyup="if (this.value.length > 2) searchA(this.value)" placeholder="Buscar articulo..." autocomplete="off">
									<div class="sugerencias a"></div>
									<input type="hidden" id="clvA">
								</td>
								<td><button type="button" class="ok" onclick="if ($('#clvA').val() != '') addArticulo()"><i class="fa fa-plus"></i></button></td>
							</tr>
						</table>

						<table id="lista" style="width: 100%; border-top: 2px solid black; border-bottom: 2px solid black; padding-top: 8px; margin-top: 8px;" cellspacing="0">
							<thead>
								<tr>
									<th>Descripción Articulo</th>
									<th>Modelo</th>
									<th>Cantidad</th>
									<th>Precio</th>
									<th>Importe</th>
									<th>&nbsp;</th>
								</tr>
							</thead>
							<tbody></tbody>
						</table>

						<table class="tbl" style="text-align: right;">
							<tr>
								<td>Enganche:</td><td id="eng">0</td>
							</tr>
							<tr>
								<td>Bonificación Enganche:</td><td id="bonEng">0</td>
							</tr>
							<tr>
								<td>Total:</td><td id="tot">0</td>
							</tr>
						</table>

						<div id="abonos" style="margin-top: 50px;"></div>
					</form>
				</div>
			</div>
			<div class="btns">
				<input type="button" class="no" onclick="seguro()" value="Cancelar">
				<input type="button" class="ok" onclick="ventas3(this)" value="Siguiente">
			</div>
		</div>

	</div>
	<script type="text/javascript">
		$('#btn-new').click(function(event) {
			$('#uno').hide();
			$('#dos').show();
		});
		function seguro() {
			if (confirm('¿Seguro que desea salir de la pantalla actual?')) document.location = '/index.php';
		}
		function searchC(v) {
			$.ajax({type: "POST", url: "/ajax/autocomplete.php", data: 't=c&txt='+v,
				success: function(data) {
					$('.sugerencias.c').show().html(data);
					$('.sugerencias.c .elemento').click(function(event) {
						$('#clvC').val($(this).attr('clv'));
						$('#rfc').text($(this).attr('rfc'));
						$('#cliente').val($(this).attr('clv') + ' - ' + $(this).text());
						$('.sugerencias.c').hide();
					});
				}
			});
		}
		function searchA(v) {
			$.ajax({type: "POST", url: "/ajax/autocomplete.php", data: 't=a&txt='+v,
				success: function(data) {
					$('.sugerencias.a').show().html(data);
					$('.sugerencias.a .elemento').click(function(event) {
						$('#clvA').val($(this).attr('clv'));
						$('#articulo').val($(this).attr('clv') + ' - ' + $(this).text());
						$('.sugerencias.a').hide();
					});
				}
			});
		}
		function addArticulo() {
			var clv = $('#clvA').val();
			if ($('#lista tbody tr[clv="'+clv+'"]').length) alert('El producto ya está en la lista');
			else $.post('/ajax/addArticulo.php', {'clv': clv}, function(data, textStatus, xhr) {
				if (data != '0') {
					$('#lista tbody').append(data);
					calcularDatos();
				} else {
					alert('El artículo seleccionado no cuenta con existencia, favor de verificar');
				}
				$('#articulo, #clvA').val('');
			});
		}
		function setImporte(obj) {
			var tr = $(obj).closest('tr');
			var p = tr.find('.p').text().replace(',', '');  // precio del articulo
			var imp = (obj.value * p).toFixed(2);  // importe = cantidad * precio
			tr.find('.i').text(imp);
			calcularDatos();
		}
		function delArticulo(obj) {
			$(obj).closest('tr').remove();
			calcularDatos();
		}
		function ventas3(obj) {
			// revisar que esté seleccionado un cliente y que haya al menos un articulo seleccionado
			if (($('#clvC').val() == '') || !$('#lista tbody tr').length) alert('Los datos ingresados no son correctos, favor de verificar');
			else {
				$.post('/ajax/abonos.php', {tot: $('#tot').text()}, function(data, textStatus, xhr) {
					$('#articulo').closest('tr').hide();
					$('#abonos').show().html(data);
					obj.value = 'Guardar';
					$(obj).attr('onclick', "alert('Debe seleccionar un plazo para realizar el pago de su compra')");
				});
			}
		}
		function chk(obj) {
			$('input.ok').attr('onclick', 'comprar()');
		}
		function comprar() {
			$.post('/ajax/setVenta.php', $('#ventaTotal').serialize(), function(data, textStatus, xhr) {
				alert("Bien Hecho, Tu venta ha sido registrada correctamente");
				document.location = '/index.php';
			});
		}

		function calcularDatos() {
			var imp, eng, bonEng, tot; // datos del articulo
			var lista = $('#lista tbody tr .i');  // lista de importes de articulos
			var enganche = 0.0, bonificacionEnganche = 0.0, total = 0.0;  // datos de la lista completa
			for (var i = 0; i < lista.length; i++) {
				imp = parseFloat($(lista[i]).text());
				
				eng = ((<?=$porcEnganche?>/100)*imp).toFixed(2);
				bonEng = (eng*((<?=$tasaFinanciamiento?> * <?=$plazoM?>)/100)).toFixed(2);
				tot = (imp - eng - bonEng).toFixed(2);

				enganche += eng;
				bonificacionEnganche += bonEng;
				total += tot;
			}
			$('#eng').text(parseFloat(enganche).toFixed(2));
			$('#bonEng').text(parseFloat(bonificacionEnganche).toFixed(2));
			$('#tot').text(parseFloat(total).toFixed(2));
		}
	</script>

</body>
</html>